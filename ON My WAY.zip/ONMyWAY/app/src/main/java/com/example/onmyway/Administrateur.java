package com.example.onmyway;

public class Administrateur {

    public static final String email="hassan@gmail.com";
    public static final String password="hassan123";
    public static final String id="EeO1NoqFwRbJIRgNAwwz4nMt5jv2";


}
